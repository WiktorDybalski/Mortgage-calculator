package mortgage.services;

import mortgage.model.InputData;

public interface MortgageCalculationService {

    void calculate(InputData inputData);
}
