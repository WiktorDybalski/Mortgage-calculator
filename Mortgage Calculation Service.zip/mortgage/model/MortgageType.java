package mortgage.model;

public enum MortgageType {
    CONSTANT,
    DECREASING
}
